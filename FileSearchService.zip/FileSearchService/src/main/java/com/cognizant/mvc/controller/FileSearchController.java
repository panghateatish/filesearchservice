package com.cognizant.mvc.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.mvc.model.FileSearchWords;
import com.cognizant.mvc.service.IFileSearchService;

@Controller
public class FileSearchController {
    @Autowired
	IFileSearchService fileSearchService;

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public String searchFiles(
			@ModelAttribute("searchForm") FileSearchWords searchWords,
			ModelMap model) {

		if (null != searchWords) {

			List<String> fileList = fileSearchService.searchFiles(searchWords
					.getSearchWords());
			model.addAttribute("fileList", fileList);
		}

		return "searchResult";

	}

	@RequestMapping(value = "/file", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downLoadFile(
			@RequestParam(value = "filePath", required = true) String filePath)
			throws IOException {

		byte[] documentBody = fileSearchService.readBytesFromFile(filePath);
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		responseHeaders.set("Content-disposition", "attachment; filename="
				+ filePath.substring(filePath.lastIndexOf("\\") + 1));
		responseHeaders.setContentLength(documentBody.length);

		return new ResponseEntity<byte[]>(documentBody, responseHeaders,
				HttpStatus.OK);

	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String searchForm(Model model) {

		model.addAttribute("searchForm", new FileSearchWords());
		return "search";

	}

}

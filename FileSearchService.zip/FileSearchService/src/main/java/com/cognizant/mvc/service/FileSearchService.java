package com.cognizant.mvc.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class FileSearchService implements IFileSearchService {

	@Value("${SEARCH_DIRECTORY}")
	private String searchDirectory;

	@Override
	public List<String> searchFiles(String words) {

		StringTokenizer tokens = new StringTokenizer(words, " ");
		List<String> fileList = new ArrayList<>();
		List<String> fileWords = new ArrayList<>();

		while (tokens.hasMoreElements()) {

			fileWords.add(tokens.nextToken());
		}

		try {
			fileList = searchFileForWords(searchDirectory, fileWords);

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		}

		return fileList;
	}

	private List<String> searchFileForWords(String searchDirectory,
			List<String> fileWords) throws FileNotFoundException {
		// TODO Auto-generated method stub
		List<File> resultFileList = new ArrayList<>();
		List<String> matchedFileList = new ArrayList<>();
		resultFileList = searchDirectory(searchDirectory, resultFileList); // get list of all files in directory
		Scanner scanner = null;
		File file = null;
		for (String word : fileWords) { //check for each word in file

			for (Iterator<File> itr = resultFileList.iterator(); itr.hasNext();) {

				file = itr.next();
				scanner = new Scanner(file);
				while (scanner.hasNextLine()) {

					String line = scanner.next();
					if (null != line && line.contains(word)) {
						matchedFileList.add(file.getAbsolutePath());
						itr.remove();

					}
					

				}
				scanner.close();
			}
		}

		return matchedFileList;
	}

	private List<File> searchDirectory(String searchConfiguredDirectory,
			List<File> resultFileList) {

		File directory = new File(searchConfiguredDirectory);
		File[] fList = directory.listFiles();
		for (File file1 : fList) {

			if (file1.isFile()) {
				resultFileList.add(file1);

			} else if (file1.isDirectory()) {

				searchDirectory(file1.getAbsolutePath(), resultFileList);
			}
		}

		return resultFileList;
	}

	@Override
	public byte[] readBytesFromFile(String filePath) {

		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;

		try {

			File file = new File(filePath);
			bytesArray = new byte[(int) file.length()];

			// read file into bytes[]
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;

	}

}

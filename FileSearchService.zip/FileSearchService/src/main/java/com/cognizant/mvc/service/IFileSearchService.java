package com.cognizant.mvc.service;

import java.util.List;

public interface IFileSearchService {
	
	public List<String> searchFiles(String words);
	public byte[] readBytesFromFile(String filePath);
	

}

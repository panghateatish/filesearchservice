package com.cognizant.mvc.model;

public class FileSearchWords {
	
	private String searchWords;

	public String getSearchWords() {
		return searchWords;
	}

	public void setSearchWords(String searchWords) {
		this.searchWords = searchWords;
	}

}
